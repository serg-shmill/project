#!/usr/bin/python
# -*- coding: utf-8 -*-

# Импорт необходимых библиотек

import sys
import getopt
from datetime import datetime
import pandas as pd
from sqlalchemy import create_engine

if __name__ == "__main__":
	unixOptions = "s:e"
	gnuOptions = ["start_dt=", "end_dt="]
	fullCmdArguments = sys.argv
	argumentList = fullCmdArguments[1:]

	try:
		arguments, values = getopt.getopt(argumentList, unixOptions, gnuOptions)
	except getopt.error as err:
		print (str(err))
		sys.exit(2)

	start_dt = '2019-09-24 18:00:00'
	end_dt = '2019-09-24 19:00:00'
	for currentArgument, currentValue in arguments:
		if currentArgument in ("-s", "--start_dt"):
			start_dt = currentValue
		elif currentArgument in ("-e", "--end_dt"):
			end_dt = currentValue
	db_config = {'user': 'shmil', 'pwd': 'shmil', 'host': 'localhost', 'port': 5432,	'db': 'zen'}
	connection_string = 'postgresql://{}:{}@{}:{}/{}'.format(db_config['user'], db_config['pwd'], db_config['host'], db_config['port'], db_config['db'])
	engine = create_engine(connection_string)

	query = ''' 
	SELECT * , TO_TIMESTAMP(ts / 1000) AT TIME ZONE 'Etc/UTC' AS dt
	FROM log_raw 
	WHERE TO_TIMESTAMP(ts / 1000) AT TIME ZONE 'Etc/UTC' BETWEEN '{}'::TIMESTAMP AND '{}'::TIMESTAMP 
	'''.format(start_dt, end_dt) 

	log_raw = pd.io.sql.read_sql(query, con = engine, index_col = 'event_id')

	log_raw['dt'] = pd.to_datetime(log_raw['dt']).dt.round('min')

	dash_visits = log_raw.groupby(['item_topic', 'source_topic', 'age_segment', 'dt']).agg({'user_id': 'count'}).reset_index()
	dash_engagement = log_raw.groupby(['dt', 'item_topic', 'event', 'age_segment']).agg({'user_id': 'nunique'}).reset_index()

	dash_visits = dash_visits.rename(columns = {'user_id': 'visits'})
	dash_engagement = dash_engagement.rename(columns = {'user_id': 'unique_users'})

	dash_visits.to_sql(name = 'dash_visits', con = engine, if_exists = 'append', index = False)
	dash_engagement.to_sql(name = 'dash_engagement', con = engine, if_exists = 'append', index = False)

	#print(dash_engagement.head(5))