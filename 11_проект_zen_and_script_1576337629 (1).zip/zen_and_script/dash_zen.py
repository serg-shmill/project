#!/usr/bin/python
# -*- coding: utf-8 -*-

import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output

import plotly.graph_objs as go

from datetime import datetime

import pandas as pd

# задаём данные для отрисовки
from sqlalchemy import create_engine

db_config = {'user': 'shmil', 'pwd': 'shmil', 'host': 'localhost', 'port': 5432,    'db': 'zen'}
connection_string = 'postgresql://{}:{}@{}:{}/{}'.format(db_config['user'], db_config['pwd'], db_config['host'], db_config['port'], db_config['db'])
engine = create_engine(connection_string)

query = ''' SELECT * FROM dash_visits '''
dash_visits = pd.io.sql.read_sql(query, con = engine, index_col = 'record_id')
dash_visits['dt'] = pd.to_datetime(dash_visits["dt"])

query = ''' SELECT * FROM dash_engagement '''
dash_engagement = pd.io.sql.read_sql(query, con = engine, index_col = 'record_id')
dash_engagement['dt'] = pd.to_datetime(dash_engagement["dt"])

note = ''' 
Этот дашборд показывает историю взаимодействия пользователей с карточками Яндекс.Дзен.
Используйте выбор интервала даты и времени для управления дашбордом, выбор возрастных 
групп и тем карточек.
'''

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets,compress=False)
app.layout = html.Div(children=[
    html.H1(children = 'История взаимодействия пользователей с карточками Яндекс.Дзен'),
    html.Br(),
    html.Label(note),
    html.Br(),
    
    html.Div([
        html.Div([html.Label('Фильтр даты и времени'),
            dcc.DatePickerRange(
                start_date = dash_engagement['dt'].min(),
                end_date = dash_engagement['dt'].max(),
                display_format = 'YYYY-MM-DD HH:MM:SS',
                #style = {'height': '10vw'},
                id = 'dt_selector'
            ),
            html.Label('Фильтр возрастных категорий'),
            dcc.Dropdown(
                options = [{'label': x, 'value': x} for x in dash_visits['age_segment'].unique()],
                value = dash_visits['age_segment'].unique().tolist(),
                multi = True,
                #style = {'height': '10vw'},
                id = 'age_selector'
            )
        ], className = 'six columns'),
        html.Div([html.Label('Фильр тем карточек'),
            dcc.Dropdown(
                options = [{'label': x, 'value': x} for x in dash_visits['item_topic'].unique()],
                value = dash_visits['item_topic'].unique().tolist(),
                multi = True,
                #style = {'height': '20vw'},
                id = 'item_topic_selector'
            )
        ], className = 'six columns')
    ], className = 'row'),

    html.Br(),

    html.Div([
        html.Div([html.Label('График историй событий по всем темам карточек. Все типы событийб абсолютные значения'),
            dcc.Graph(
                style = {'height': '50vw'},
                id = 'history_absolute_visits'
            )
        ], className = 'six columns'
        ),
        html.Div([html.Label('График разбивки событий по темам источников. Все типы событий - относительные значения (больше 3%)'),
            dcc.Graph(
                style = {'height': '25vw'},
                id = 'pie_visits'
            )
        ], className = 'six columns'
        ),
        html.Div([html.Label('График средней глубины взаимодействия'),
            dcc.Graph(
                style = {'height': '25vw'},
                id = 'engagement_graph'
            ),
        ], className = 'six columns'
        ),
    ], className = 'row')
])
@app.callback(
    [Output('history_absolute_visits', 'figure'),
    Output('pie_visits', 'figure'),
    Output('engagement_graph', 'figure')
    ],
    [Input('dt_selector', 'start_date'),
    Input('dt_selector', 'end_date'),
    Input('age_selector', 'value'),
    Input('item_topic_selector', 'value')
    ])

def update_figures(start_date, end_date, selected_age_segment, selected_item_topic):
    start_date = datetime.strptime(start_date, '%Y-%m-%dT%H:%M:%S')
    end_date = datetime.strptime(end_date, '%Y-%m-%dT%H:%M:%S')
    filtered_visits = dash_visits.query('dt >= @start_date and dt <= @end_date')
    filtered_engagement = dash_engagement.query('dt >= @start_date and dt <= @end_date')

    filtered_visits = filtered_visits.query('age_segment in @selected_age_segment')
    filtered_engagement = dash_engagement.query('age_segment in @selected_age_segment')

    filtered_visits = filtered_visits.query('item_topic in @selected_item_topic')
    filtered_engagement = dash_engagement.query('item_topic in @selected_item_topic')

    event_by_zen = filtered_engagement.groupby(['dt', 'event']).agg({'unique_users': 'sum'}).reset_index()
    visits_source_topic = filtered_visits.groupby('source_topic').agg({'visits': 'sum'}).reset_index()
    event_avg = filtered_engagement.groupby('event').agg({'unique_users': 'mean'}).reset_index()
    event_avg = event_avg.sort_values(by = 'unique_users', ascending = False)
    visits_source_topic['share'] = visits_source_topic['visits'] / visits_source_topic['visits'].sum()

    engagement_by_item_topic = filtered_visits.groupby(['dt', 'item_topic']).agg({'visits': 'sum'}).reset_index()

    def share(data):
        share = data['share']
        source_topic = data['source_topic']
        if share > 0.03:
            return source_topic
        else:
            return 'OTHER'



    visits_source_topic['group'] = visits_source_topic.apply(share, axis=1)
    summery = visits_source_topic.groupby(['group']).agg({'share': 'sum', 'visits': 'sum'}).reset_index()




    data_by_item_topic =[]
    data_by_avgevent = []
    for item_topic in engagement_by_item_topic['item_topic'].unique():
        data_by_item_topic += [go.Scatter(x = engagement_by_item_topic.query('item_topic == @item_topic')['dt'],
            y = engagement_by_item_topic.query('item_topic == @item_topic')['visits'],
            mode = 'lines',
            stackgroup = 'one',
            name = item_topic)]
    data_by_avgevent = [go.Bar(x = event_avg['event'],
        y = event_avg['unique_users']
            )]


    data_visit_source_topic =[go.Pie(labels = summery['group'],
        values = summery['visits'],
        name = 'group')]

    return({
        'data': data_by_item_topic,
        'layout': go.Layout(xaxis = {'title': 'Дата и время'},
            yaxis = {'title': 'Событие в системе ZEN'})
        },
        {
        'data': data_visit_source_topic,
        'layout': go.Layout()
        },
        {
        'data': data_by_avgevent,
        'layout': go.Layout(xaxis = {'title': 'Событие'},
            yaxis = {'title': 'Среднее значение уникальных посетителей'},
            barmode = 'stack'
            )
        }
    )





if __name__ == '__main__':
    app.run_server(debug=True)