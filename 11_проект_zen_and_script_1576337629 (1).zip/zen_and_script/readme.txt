ОС Ubuntu

1. Загрузите в базу данных из бэкап-файла:

pg_restore -d zen zendump

2. Открытие дашборта

python3 dash_zen.py


