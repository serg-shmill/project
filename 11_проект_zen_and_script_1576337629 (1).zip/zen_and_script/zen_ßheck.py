#!/usr/bin/python
# -*- coding: utf-8 -*-

# Импорт необходимых библиотек

import sys
import getopt
from datetime import datetime
import pandas as pd
from sqlalchemy import create_engine

if __name__ == "__main__":
	db_config = {'user': 'shmil', 'pwd': 'shmil', 'host': 'localhost', 'port': 5432,	'db': 'zen'}
	connection_string = 'postgresql://{}:{}@{}:{}/{}'.format(db_config['user'], db_config['pwd'], db_config['host'], db_config['port'], db_config['db'])
	engine = create_engine(connection_string)

	query = ''' SELECT * FROM dash_visits '''
	dash_visits = pd.io.sql.read_sql(query, con = engine, index_col = 'record_id')
	dash_visits['dt'] = pd.to_datetime(dash_visits["dt"])

	query = ''' SELECT * FROM dash_engagement '''
	dash_engagement = pd.io.sql.read_sql(query, con = engine, index_col = 'record_id')
	dash_engagement['dt'] = pd.to_datetime(dash_engagement["dt"])

	print(dash_engagement['dt'].min())
	print()
	print(dash_engagement['dt'].max())